export { default } from './polymorphic.mixin';
