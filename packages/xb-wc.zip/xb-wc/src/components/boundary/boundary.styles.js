import { css } from 'lit';

function styles() {
	return [
		css`
			:host {
				display: contents;
			}
		`,
	];
}

export default styles;
