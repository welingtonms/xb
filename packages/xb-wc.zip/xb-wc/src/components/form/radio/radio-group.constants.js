export const CHECK_EVENT = 'xb-check';
