export const TOGGLE_EVENT = 'xb-toggle';
