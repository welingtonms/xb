import { css } from 'lit';

function styles() {
	return [
		css`
			:host {
			}
		`,
	];
}

export default styles;
