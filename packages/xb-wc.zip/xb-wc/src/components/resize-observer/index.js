export { XBResizeObserver } from './resize-observer';
