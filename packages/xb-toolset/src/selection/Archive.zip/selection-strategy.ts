import toArray from '../to-array';

export const SELECTION_TYPES = [ 'single', 'single-strict', 'multiple' ] as const;

export type SelectionType = ( typeof SELECTION_TYPES )[ number ];

export type GenericSelectableObject = {
	value: string;
};

export type CustomSelectableObject = {
	_type: string;
};

export type Selectable = string | GenericSelectableObject | CustomSelectableObject;

export type SelectionAdapter = {
	/**
	 * get unique identifier for the given object
	 */
	getValue: ( obj: GenericSelectableObject | CustomSelectableObject ) => string;
};

export type SelectionState = Map< string, Selectable >;

export type SelectionStrategyContext = {
	/**
	 * Get value for the given selectable value.
	 */
	getValue: ( selectable: Selectable ) => string;
};

export type SelectionStrategy = {
	type: SelectionType;
	/**
	 * Set the initial selection.
	 */
	init: { ( values: Selectable | Selectable[] | null ): SelectionState };
	/**
	 * Add the provided `values` to the `selection`, respecting
	 * the rules for the current strategy.
	 */
	select: {
		(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState;
	};
	/**
	 * Remove the provided `values` from the `selection`, respecting
	 * the rules for the current strategy.
	 */
	unselect: {
		(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState;
	};
	/**
	 * Toggle the provided `values` from the `selection` (add to the selection if
	 * not in the `selection`, remove from the `selection` otherwise respecting
	 * the rules for the current strategy.
	 */
	toggle: {
		(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState;
	};
	/**
	 * Reset `selection` to the provided value, or to and empty `Set` otherwise.
	 */
	reset: { ( selection?: SelectionState ): SelectionState };
	/**
	 * Return selection as a value, based on the `AcceptedType`.
	 * @param {SelectionState} selection
	 */
	value: { ( selection?: SelectionState ): unknown };
};

export type SelectionStrategyCreationProps = {
	type?: SelectionType;
	adapters?: Record< string, SelectionAdapter >;
};

export const GenericAdapter: SelectionAdapter = {
	getValue( item: GenericSelectableObject | CustomSelectableObject ) {
		return String( ( item as { value: string } ).value );
	},
};

function isCustomSelectableObject( object: any ): object is CustomSelectableObject {
	return '_type' in object;
}

/**
 * @param {Object} props
 * @param {SelectionType} [props.type]
 * @returns {SelectionStrategy}
 */
function createSelectionStrategy(
	props: SelectionStrategyCreationProps
): SelectionStrategy {
	const { type = 'multiple', adapters } = props;

	const context: SelectionStrategyContext = {
		getValue( selectable: Selectable ) {
			if ( typeof selectable === 'string' ) {
				return selectable;
			}

			let adapter = GenericAdapter;
			if (
				isCustomSelectableObject( selectable ) &&
				adapters[ selectable._type ] != null
			) {
				adapter = adapters[ selectable._type ];
			}

			return adapter.getValue( selectable );
		},
	};

	let strategy;

	switch ( type ) {
		case 'single':
			strategy = SingleSelectionStrategy( context );
			break;
		case 'single-strict':
			strategy = SingleStrictSelectionStrategy( context );
			break;
		case 'multiple':
		default:
			strategy = MultipleSelectionStrategy( context );
			break;
	}

	return Object.freeze( strategy );
}

/**
 * This strategy requires that once a selection is made,
 * one item has to be selected, always.
 * @returns {SelectionStrategy}
 */
export function SingleStrictSelectionStrategy(
	context: SelectionStrategyContext
): SelectionStrategy {
	return {
		type: 'single-strict',
		init( values: Selectable | Selectable[] | null ): SelectionState {
			return this.select( values, new Map() );
		},
		select(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			// We always start with an empty map, as we are handling single selection
			const newSelection = new Map< string, Selectable >();
			const last = safeValues[ safeValues.length - 1 ];

			newSelection.set( context.getValue( last ), last );

			return newSelection; //?
		},
		unselect(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 || selection.size == 0 ) {
				return selection;
			}

			const newSelection = new Map< string, Selectable >( selection );

			for ( let i = 0; i < safeValues.length && selection.size > 1; i++ ) {
				newSelection.delete( context.getValue( safeValues.at( i ) ) );
			}

			return newSelection;
		},
		toggle(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			const newSelection = new Map< string, Selectable >( selection );

			for ( let i = 0; i < safeValues.length; i++ ) {
				const value = context.getValue( safeValues.at( i ) );

				if ( ! selection.has( value ) ) {
					newSelection.clear();
					newSelection.set( value, safeValues.at( i ) );
				}
			}

			return newSelection;
		},
		reset( selection?: SelectionState ) {
			if ( selection == null ) {
				return new Map< string, Selectable >();
			}

			return selection;
		},
		value( selection?: SelectionState ): Selectable | null {
			if ( selection == null || selection.size === 0 ) {
				return null;
			}

			const [ first ] = Array.from( selection.values() );
			return first;
		},
	};
}

/**
 * This strategy requires one or no item to be selected.
 * @returns {SelectionStrategy}
 */
export function SingleSelectionStrategy(
	context: SelectionStrategyContext
): SelectionStrategy {
	return {
		type: 'single',
		init( values: Selectable | Selectable[] | null ): SelectionState {
			return this.select( values, new Map() );
		},
		select(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			// We always start with an empty map, as we are handling single selection
			const newSelection = new Map< string, Selectable >();

			newSelection.set(
				context.getValue( safeValues.at( safeValues.length - 1 ) ),
				safeValues.at( safeValues.length - 1 )
			);

			return newSelection;
		},
		unselect(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 || selection.size == 0 ) {
				return selection;
			}

			const newSelection = new Map< string, Selectable >( selection );

			for ( let i = 0; i < safeValues.length; i++ ) {
				newSelection.delete( context.getValue( safeValues.at( i ) ) );
			}

			return newSelection;
		},
		toggle(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			/** @type {SelectionState} */
			const newSelection = new Map< string, Selectable >();

			for ( let i = 0; i < safeValues.length; i++ ) {
				const value = context.getValue( safeValues.at( i ) );

				if ( ! selection.has( value ) ) {
					newSelection.clear();
					newSelection.set( value, safeValues.at( i ) );
				}
			}

			return newSelection;
		},
		/**
		 * @param {SelectionState} selection
		 * @returns {SelectionState}
		 */
		reset( selection?: SelectionState ) {
			if ( selection == null ) {
				return new Map< string, Selectable >();
			}

			return selection;
		},
		value( selection?: SelectionState ): Selectable | null {
			if ( selection == null || selection.size === 0 ) {
				return null;
			}

			const [ first ] = Array.from( selection.values() );
			return first;
		},
	};
}

/**
 * This strategy requires one or no item to be selected.
 * @returns {SelectionStrategy}
 */
export function MultipleSelectionStrategy(
	context: SelectionStrategyContext
): SelectionStrategy {
	return {
		type: 'multiple',
		init( values: Selectable | Selectable[] | null ): SelectionState {
			return this.select( values, new Map() );
		},
		select(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			const newSelection = new Map( selection );

			for ( let i = 0; i < safeValues.length; i++ ) {
				newSelection.set( context.getValue( safeValues.at( i ) ), safeValues.at( i ) );
			}

			return newSelection;
		},
		unselect(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 || selection.size == 0 ) {
				return selection;
			}

			const newSelection = new Map( selection );

			for ( let i = 0; i < safeValues.length; i++ ) {
				newSelection.delete( context.getValue( safeValues.at( i ) ) );
			}

			return newSelection;
		},
		toggle(
			values: Selectable | Selectable[] | null,
			selection: SelectionState
		): SelectionState {
			const safeValues = toArray( values );

			if ( safeValues.length == 0 ) {
				return selection;
			}

			const newSelection = new Map( selection );

			for ( let i = 0; i < safeValues.length; i++ ) {
				const value = context.getValue( safeValues.at( i ) );

				if ( ! selection.has( value ) ) {
					newSelection.set( value, safeValues.at( i ) );
				} else {
					newSelection.delete( value );
				}
			}

			return newSelection;
		},
		reset( selection?: SelectionState ) {
			if ( selection == null ) {
				return new Map< string, Selectable >();
			}

			return selection;
		},
		value( selection?: SelectionState ): Selectable[] | null {
			if ( selection == null || selection.size === 0 ) {
				return null;
			}

			return Array.from( selection.values() );
		},
	};
}

// export function MultipleSelectionStrategy(
//   context: SelectableStrategyContext<T>
// ): SelectableStrategy<T> {
//   return {
//     type(): SelectionStrategy {
//       return 'multiple'
//     },
//     init(items: T[]) {
//       return this.select(items, new Map<SelectableKeyType, T>())
//     },
//     select(items: T[], selection: SelectableState<T>) {
//       const newSelection = new Map<SelectableKeyType, T>(selection)

//       for (let i = 0; i < items.length; i++) {
//         const adapter = context.getAdapter(items[i]._type)
//         newSelection.set(adapter.getKey(items[i]), items[i])
//       }

//       return newSelection
//     },
//     unselect(keys: SelectableKeyType[], selection: SelectableState<T>) {
//       const newSelection = new Map<SelectableKeyType, T>(selection)

//       for (let i = 0; i < keys.length; i++) {
//         newSelection.delete(keys[i])
//       }

//       return newSelection
//     },
//     toggle(items: T[], selection: SelectableState<T>) {
//       const newSelection = new Map<SelectableKeyType, T>(selection)

//       for (let i = 0; i < items.length; i++) {
//         const adapter = context.getAdapter(items[i]._type)
//         const key = adapter.getKey(items[i])

//         if (!selection.has(key)) {
//           newSelection.set(key, items[i])
//         } else {
//           newSelection.delete(key)
//         }
//       }

//       return newSelection
//     },
//     clear(): SelectionStrategy {
//       return new Map<SelectableKeyType, T>()
//     },
//   }
// }

export default createSelectionStrategy;
